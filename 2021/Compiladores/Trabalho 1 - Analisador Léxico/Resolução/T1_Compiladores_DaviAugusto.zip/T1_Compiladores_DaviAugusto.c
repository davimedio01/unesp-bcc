/*
Nome: Davi Augusto Neves Leite
RA: 191027383

Realizado em: Windows 10 (x64) e compilado pelo TDM-GCC x64 (https://jmeubank.github.io/tdm-gcc/)
Deixar o programa e arquivo texto (Trab1_Compiladores.txt) no MESMO DIRETÓRIO.
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <malloc.h>
#include <string.h>

#define MAX_TOKEN 1000               //Define o tamanho máximo de escrita de um átomo
#define MAX_KEYWORD 10              //Define o tamanho máximo das palavras reservadas
#define MAX_SYMBOL 12               //Define o conjunto máximo de símbolos especiais da linguagem

typedef long long int lld;

//Variáveis GLOBAIS
int varSymbol; //Marca o código de identificação do último átomo analisado

//Par de identificador e token
typedef struct pair pairSymbol;
struct pair{
    int identifier;           //Salva o identificador (número) do átomo associado
    char token[MAX_TOKEN];    //Salva o átomo associado
};

//Tabela de Símbolos por LISTA ENCADEADA (não se sabe o limite de átomos...)
typedef struct symbol *table;
struct symbol{
    pairSymbol pair;    //Par com o identificador e o átomo (palavra) associada
    struct symbol *prox;
};
table symbolTable;

///////////////////////////////////////////////////////////
//* FUNÇÕES DO ANALISADOR LÉXICO *//
///////////////////////////////////////////////////////////
//Função PROXIMO: responsável por pular linhas vazias e espaços em branco
char PROXIMO(FILE *arq){
    return toupper(fgetc(arq));
}
///////////////////////////////////////////////////////////
//Função CÓDIGO: responsável por verificar na tabela (matriz) de símbolos os identificadores e seus respectivos átomos associados!
//Insere caso não esteja contido na tabela...
int CODIGO(char *token, lld *countTableSymbol){
    //Percorre a tabela de símbolos em busca do átomo associado
    table p = symbolTable;
    while(p){
        if(strcmp(p->pair.token, token) == 0){
            return p->pair.identifier;
        }
        p = p->prox;
    }

    //Caso não tenha encontrado nada, insere o átomo na tabela e retorna o valor do identificador associado
    pairSymbol pair;
    pair.identifier = (*countTableSymbol)++;
    strcpy(pair.token, token);

    endInsertList(pair); //Inserção no fim da Tabela de Símbolos

    return pair.identifier; //Retorna o identificador do elemento inserido atualmente
}

///////////////////////////////////////////////////////////
//Função ERRO: retorna um erro ao usuário e a linha em que foi encontrado o erro
void ERRO(lld line){
    printf("\nERRO DE COMPILACAO!\n\n");
    printf("Ocorreu um erro lexico na linha %lld do codigo-fonte!", line);
    printf("\n\n");
    system("PAUSE");
    exit(0);
}

///////////////////////////////////////////////////////////
//Verificador de LETRAS
int isLetter(char character){
    return ((character >= 'A') && (character <= 'Z'));
}

//Verificador de NÚMEROS
int isNumber(char character){
    return ((character >= '0') && (character <= '9'));
}

//Verificador de LETRAS e DÍGITOS
int isLetterOrNumber(char character){
    return (isLetter(character) || isNumber(character));
}

//Verificador de SÍMBOLOS ESPECIAIS
int isSpecialSymbol(char character){
    //Símbolos Especiais do PASCAL
    char symbols[MAX_SYMBOL] = {".;,():=<>+-*"};

    int i;
    for(i = 0; i < MAX_SYMBOL; i++){
        if(character == symbols[i]){
            //Caso o caractere seja um símbolo especial
            return 1;
        }
    }
    return 0;
}

//Verificador de PALAVRAS-CHAVE
int isKeyword(char *word){
    //Palavras-Chave do PASCAL: retirado diretamente do livro!
    char keywords[][MAX_KEYWORD] = {"PROGRAM", "LABEL", "TYPE", "VAR", "PROCEDURE", 
                                    "ARRAY", "OF", "FUNCTION", "BEGIN", "END", 
                                    "IF", "THEN", "ELSE", "WHILE", "DO", "OR", 
                                    "AND", "DIV", "NOT"};

    //Tamanho do Vetor de Palavras-Chave
    int size = *(&keywords + 1) - keywords;

    int i;
    for(i = 0; i < size; i++){
        if(strcmp(word, keywords[i]) == 0){
            //Caso a palavra seja uma palavra reservada
            return 1;
        }
    }
    return 0;
}
///////////////////////////////////////////////////////////
//* FUNÇÕES DA LISTA ENCADEADA *//
///////////////////////////////////////////////////////////
//Inserir ao fim da lista
void endInsertList(pairSymbol pair){
    //Alocando espaço para inserção
    table p = (table) malloc(sizeof(struct symbol));
    //Recebendo a informação
    p->pair = pair;
    p->prox = NULL;
    
    //Caso a lista esteja nula
    if(symbolTable == NULL){
        symbolTable = p;
    }
    else{
        table q = symbolTable;
        while(q->prox){
            q = q->prox;
        }
        q->prox = p;
    }
}

//Percorre a lista e retorna o par (identificador, token) associado
void retPairSymbol(int identifier, pairSymbol *auxPair){
    table p = symbolTable;

    (*auxPair).identifier = -1;

    while(p){
        if(p->pair.identifier == identifier){
            (*auxPair) = p->pair;
            break;
        }
        p = p->prox;
    }
}

///////////////////////////////////////////////////////////
//* FUNÇÕES DE ARQUIVO *//
///////////////////////////////////////////////////////////
//Abrir arquivo TEXTO
int readTextFile(FILE *(*arq), char *filename, char *mode){
    //Tenta abrir o arquivo texto por algum modo (escrita/leitura)
    return ((*arq) = fopen(filename, mode));
}
//Mostrar conteúdo do Arquivo TEXTO por CARACTERE
void printTextFile(FILE *arq){
    char character;
    while (!feof(arq)){
        character = getc(arq);
        if (!feof(arq)) //Não printar o fim de arquivo
            printf("%c", character);
    }
}
///////////////////////////////////////////////////////////
//* OUTRAS FUNÇÕES *//
///////////////////////////////////////////////////////////
//Inserir os Símbolos Especiais, Símbolos Especiais Compostos e Palavras-Chave na Tabela de Símbolos
void insertSpecialSymbolsOnSymbolTable(lld *countTableSymbol){
    (*countTableSymbol) = 0;
    int i = 0, size;
    pairSymbol pair;

    ///////////////////////////////////////////////////////////
    //Palavras-Chave do PASCAL
    ///////////////////////////////////////////////////////////
    char keywords[][MAX_KEYWORD] = {"PROGRAM", "LABEL", "TYPE", "VAR", "PROCEDURE",
                                    "ARRAY", "OF", "FUNCTION", "BEGIN", "END",
                                    "IF", "THEN", "ELSE", "WHILE", "DO", "OR",
                                    "AND", "DIV", "NOT"};
    
    size = *(&keywords + 1) - keywords; //Tamanho da tabela de palavras-chave
    for(i = 0; i < size; i++){
        pair.identifier = (*countTableSymbol)++;
        strcpy(pair.token, keywords[i]);

        //Inserção na Tabela de Símbolos
        endInsertList(pair);
    }

    ///////////////////////////////////////////////////////////
    //Símbolos Especiais do PASCAL
    ///////////////////////////////////////////////////////////
    char symbols[][5] = {".", ";", ",", "(", 
                        ")", ":", "=", "<", 
                        ">", "+", "-", "*"};

    size = *(&symbols + 1) - symbols; //Tamanho da tabela de símbolos
    for (i = 0; i < size; i++){
        pair.identifier = (*countTableSymbol)++;
        strcpy(pair.token, symbols[i]);

        //Inserção na Tabela de Símbolos
        endInsertList(pair);
    }

    ///////////////////////////////////////////////////////////
    //Símbolos Especiais Compostos do PASCAL
    ///////////////////////////////////////////////////////////
    char specialSymbols[][5] = {":=", "..", "(*", "*)"};

    size = *(&specialSymbols + 1) - specialSymbols; //Tamanho da tabela de símbolos especiais compostos
    for (i = 0; i < size; i++){
        pair.identifier = (*countTableSymbol)++;
        strcpy(pair.token, specialSymbols[i]);

        //Inserção na Tabela de Símbolos
        endInsertList(pair);
    }
}

///////////////////////////////////////////////////////////

int main(){

    //Abertura de Arquivo Texto
    FILE *arq;
    char *filename = "Trab1_Compiladores.txt"; //Diretório/Nome do arquivo (neste caso, local...)
    char *mode = "rt"; //Leitura de Arquivo Texto com opção de Escrita

    if(readTextFile(&arq, filename, mode)){
        //Sucesso na abertura do arquivo texto!
        
        ///////////////////////////////////////////////////////////////
        //Estruturas do Analisador Léxico
        ///////////////////////////////////////////////////////////////
        //Átomo/Token (palavra encontrada)
        char token[MAX_TOKEN] = "\0";
        varSymbol = -1;         //Inicia a identificação GLOBAL com nulo (-1)
        lld countTableSymbol;   //Contador para os identificadores na inserção da Tabela de Símbolos

        //Caractere do Código (variável "proximo") e a do anterior ("s")
        char characterCode = '\0', nextCharacterCode;
        //Linha em análise do código
        lld line = 1;

        //Inserção das palavras e símbolos pré-definidos na Tabela de Símbolos
        symbolTable = NULL;
        insertSpecialSymbolsOnSymbolTable(&countTableSymbol);

        ///////////////////////////////////////////////////////////////
        //Início de verificação do Analisador Léxico
        ///////////////////////////////////////////////////////////////
        //Percorrer o arquivo texto
        printf("Linha %d:\n", line);
        while (!feof(arq)){

            strcpy(token, "\0");

            do{
                characterCode = PROXIMO(arq);
            }while(characterCode == ' ' || characterCode == '\t');


            //Caso chegue no fim do arquivo, acabou!
            if(characterCode == EOF){
                break;
            }
            //Pulando as quebras de linha...
            else if(characterCode == '\n'){
                line++;
                printf("\nLinha %d:\n", line);
                continue;
            }

            ///////////////////////////////////////////////////////////////
            //Análise de Símbolos Especiais e Símbolos Especiais Compostos
            ///////////////////////////////////////////////////////////////
            if(isSpecialSymbol(characterCode)){

                //String associada ao símbolo especial composto
                char specialSymbol[5] = "\0";
                strncat(specialSymbol, &characterCode, 1);

                nextCharacterCode = PROXIMO(arq);

                //Símbolo-> :=
                if(characterCode == ':'){
                    if (nextCharacterCode == '='){
                        strncat(specialSymbol, &nextCharacterCode, 1);
                    }
                }
                //Símbolo-> ..
                else if(characterCode == '.'){
                    if (nextCharacterCode == '.'){
                        strncat(specialSymbol, &nextCharacterCode, 1);
                    }
                }
                //Símbolo-> (*
                else if(characterCode == '('){
                    if (nextCharacterCode == '*'){
                        strncat(specialSymbol, &nextCharacterCode, 1);
                    }
                }
                //Símbolo-> *)
                else if(characterCode == '*'){
                    if (nextCharacterCode == ')'){
                        strncat(specialSymbol, &nextCharacterCode, 1);
                    }
                }

                //Retorna o valor do Símbolo Especial associado
                varSymbol = CODIGO(specialSymbol, &countTableSymbol);
                printf("Operando Associado: %s\t\t|| Valor na Tabela de Simbolos: %d\n", specialSymbol, varSymbol);
            }


            ///////////////////////////////////////////////////////////////
            //Análise de Letras e Palavras-Chave
            ///////////////////////////////////////////////////////////////
            else if(isLetter(characterCode)){
                do
                {
                    strncat(token, &characterCode, 1);
                    characterCode = PROXIMO(arq);
                }while(isLetterOrNumber(characterCode));

                if(isKeyword(token)){
                    printf("Palavra-Chave: %s", token);
                }
                else{
                    printf("Atomo associado: %s", token);
                }

                //Retornando o código identificador de uma PALAVRA-CHAVE ou de um novo Átomo
                varSymbol = CODIGO(token, &countTableSymbol);

                printf("\t\t|| Valor na Tabela de Simbolos: %d\n", varSymbol);
            }

            ///////////////////////////////////////////////////////////////
            //Análise de Números
            ///////////////////////////////////////////////////////////////
            else if(isNumber(characterCode)){
                do{
                    strncat(token, &characterCode, 1);
                    characterCode = PROXIMO(arq);
                }while(isNumber(characterCode));

                //Caso haja letras após uma sequencia de números...
                if(isLetter(characterCode)){
                    ERRO(line);
                }

                varSymbol = CODIGO(token, &countTableSymbol);
                printf("Simbolo Numero: %s\t\t|| Valor na Tabela de Simbolos: %d\n", token, varSymbol);
            }

            ///////////////////////////////////////////////////////////////
            //Retorna erro em não ocorrência aos casos anteriores
            ///////////////////////////////////////////////////////////////
            else{
                ERRO(line);
            }

            if (characterCode != ' ' && characterCode != '\t'){
                fseek(arq, -1, SEEK_CUR);
            }
            //printf("\n");
        }


        //Caso tenha passado em TODOS os testes...
        printf("\nSUCESSO NA ANALISE LEXICA DO CODIGO-FONTE!\n\n");

        //Fechar arquivo após o uso
        fclose(arq);
    }
    else{
        //Erro na abertura de arquivo
        printf("Erro na abertura de arquivo!\n\n");
    }

    system("PAUSE");
    return 0;
}
